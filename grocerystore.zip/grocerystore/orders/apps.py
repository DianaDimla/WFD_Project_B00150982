from django.apps import AppConfig

# Configuration class for the orders app
class OrdersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField' 
    name = 'orders' 
